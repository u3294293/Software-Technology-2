import time
import random
import string
import tkinter as tk
from tkinter import messagebox, ttk
import matplotlib.pyplot as plt

class BSTNode:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return BSTNode(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        if root is None:
            return root
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

RED = True
BLACK = False

class RBNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.color = RED
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode("", "")
        self.NIL.color = BLACK
        self.NIL.left = None
        self.NIL.right = None
        self.root = self.NIL

    def _is_nil(self, node):
        return node is self.NIL

    def _left_rotate(self, x):
        y = x.right
        x.right = y.left
        if not self._is_nil(y.left):
            y.left.parent = x
        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def _right_rotate(self, y):
        x = y.left
        y.left = x.right
        if not self._is_nil(x.right):
            x.right.parent = y
        x.parent = y.parent
        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x
        x.right = y
        y.parent = x

    def insert(self, name, phone):
        existing = self.search(self.root, name)
        if existing and not self._is_nil(existing):
            existing.phone = phone
            return
        new_node = RBNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL
        new_node.color = RED
        parent = None
        current = self.root
        while not self._is_nil(current):
            parent = current
            if new_node.name < current.name:
                current = current.left
            else:
                current = current.right
        new_node.parent = parent
        if parent is None:
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node
        if new_node.parent is None:
            new_node.color = BLACK
            return
        if new_node.parent.parent is None:
            return
        self._fix_insert(new_node)

    def _fix_insert(self, z):
        while z.parent and z.parent.color == RED:
            if z.parent == z.parent.parent.left:
                uncle = z.parent.parent.right
                if uncle.color == RED:
                    z.parent.color = BLACK
                    uncle.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.right:
                        z = z.parent
                        self._left_rotate(z)
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self._right_rotate(z.parent.parent)
            else:
                uncle = z.parent.parent.left
                if uncle.color == RED:
                    z.parent.color = BLACK
                    uncle.color = BLACK
                    z.parent.parent.color = RED
                    z = z.parent.parent
                else:
                    if z == z.parent.left:
                        z = z.parent
                        self._right_rotate(z)
                    z.parent.color = BLACK
                    z.parent.parent.color = RED
                    self._left_rotate(z.parent.parent)
        self.root.color = BLACK

    def search(self, node, name):
        if self._is_nil(node) or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def delete(self, name):
        node = self.search(self.root, name)
        if self._is_nil(node):
            return
        self._rb_delete(node)

    def _transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def _minimum(self, node):
        while not self._is_nil(node.left):
            node = node.left
        return node

    def _rb_delete(self, z):
        y = z
        y_original_color = y.color
        if self._is_nil(z.left):
            x = z.right
            self._transplant(z, z.right)
        elif self._is_nil(z.right):
            x = z.left
            self._transplant(z, z.left)
        else:
            y = self._minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self._transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self._transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == BLACK:
            self._fix_delete(x)

    def _fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                sibling = x.parent.right
                if sibling.color == RED:
                    sibling.color = BLACK
                    x.parent.color = RED
                    self._left_rotate(x.parent)
                    sibling = x.parent.right
                if sibling.left.color == BLACK and sibling.right.color == BLACK:
                    sibling.color = RED
                    x = x.parent
                else:
                    if sibling.right.color == BLACK:
                        sibling.left.color = BLACK
                        sibling.color = RED
                        self._right_rotate(sibling)
                        sibling = x.parent.right
                    sibling.color = x.parent.color
                    x.parent.color = BLACK
                    sibling.right.color = BLACK
                    self._left_rotate(x.parent)
                    x = self.root
            else:
                sibling = x.parent.left
                if sibling.color == RED:
                    sibling.color = BLACK
                    x.parent.color = RED
                    self._right_rotate(x.parent)
                    sibling = x.parent.left
                if sibling.right.color == BLACK and sibling.left.color == BLACK:
                    sibling.color = RED
                    x = x.parent
                else:
                    if sibling.left.color == BLACK:
                        sibling.right.color = BLACK
                        sibling.color = RED
                        self._left_rotate(sibling)
                        sibling = x.parent.left
                    sibling.color = x.parent.color
                    x.parent.color = BLACK
                    sibling.left.color = BLACK
                    self._right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if not self._is_nil(node):
            self.inorder(node.left, result)
            result.append((node.name, node.phone, node.color))
            self.inorder(node.right, result)
        return result

    def tree_height(self, node):
        if self._is_nil(node):
            return 0
        return 1 + max(self.tree_height(node.left), self.tree_height(node.right))

class RBTreeApp:
    def __init__(self, root):
        self.tree = RedBlackTree()

        self.root = root
        self.root.title("Contact Directory RB Tree")

        frame = tk.Frame(root)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        button_frame = tk.Frame(root)
        button_frame.pack()

        self.insert_btn = tk.Button(button_frame, text="Insert Contact", command=self.insert_contact)
        self.insert_btn.grid(row=0, column=0, padx=5)

        self.search_btn = tk.Button(button_frame, text="Search Contact", command=self.search_contact)
        self.search_btn.grid(row=0, column=1, padx=5)

        self.delete_btn = tk.Button(button_frame, text="Delete Contact", command=self.delete_contact)
        self.delete_btn.grid(row=0, column=2, padx=5)

        self.show_all_btn = tk.Button(button_frame, text="Show All Contacts", command=self.show_all)
        self.show_all_btn.grid(row=0, column=3, padx=5)

        self.benchmark_btn = tk.Button(button_frame, text="Run Benchmark", command=self.benchmark)
        self.benchmark_btn.grid(row=0, column=4, padx=5)

        self.output_text = tk.Text(root, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(root, width=800, height=400, bg='white')
        self.canvas.pack(pady=10)

    # gui func
    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both name and phone number.")
            return
        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to search.")
            return
        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)
        if node and not self.tree._is_nil(node):
            color_str = "RED" if node.color == RED else "BLACK"
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\nNode Color: {color_str}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to delete.")
            return
        self.tree.delete(name)
        messagebox.showinfo("Success", f"Deleted contact (if existed): {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone, color in contacts:
                color_str = "[R]" if color == RED else "[B]"
                self.output_text.insert(tk.END, f"{color_str} Name: {name}, Phone: {phone}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree._is_nil(self.tree.root):
            return
        start_x = self.canvas.winfo_width() // 2
        start_y = 20
        level_gap = 70
        node_radius = 20
        self._draw_node(self.tree.root, start_x, start_y, self.canvas.winfo_width() // 4, level_gap, node_radius)

    def _draw_node(self, node, x, y, x_offset, level_gap, radius):
        if self.tree._is_nil(node):
            return

        if node.left and not self.tree._is_nil(node.left):
            x_left = x - x_offset
            y_left = y + level_gap
            self.canvas.create_line(x, y, x_left, y_left)
            self._draw_node(node.left, x_left, y_left, x_offset // 2, level_gap, radius)

        if node.right and not self.tree._is_nil(node.right):
            x_right = x + x_offset
            y_right = y + level_gap
            self.canvas.create_line(x, y, x_right, y_right)
            self._draw_node(node.right, x_right, y_right, x_offset // 2, level_gap, radius)

        fill_color = "salmon" if node.color == RED else "black"
        text_color = "black" if node.color == RED else "white"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color)
        display_name = node.name if len(node.name) <= 10 else node.name[:10] + "..."
        self.canvas.create_text(x, y, text=display_name, fill=text_color)


    def benchmark(self):
        self.tree = RedBlackTree()

        N = 1000
        names = [''.join(random.choices(string.ascii_lowercase, k=7)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]

        start = time.time()
        for i in range(N):
            self.tree.insert(names[i], phones[i])
        insert_time = time.time() - start

        search_names = random.sample(names, N // 2) + ['notfoundname'] * (N // 2)
        start = time.time()
        found_count = 0
        for name in search_names:
            node = self.tree.search(self.tree.root, name)
            if node and not self.tree._is_nil(node):
                found_count += 1
        search_time = time.time() - start

        delete_names = random.sample(names, 100)
        start = time.time()
        for name in delete_names:
            self.tree.delete(name)
        delete_time = time.time() - start

        result_text = (
            f"Benchmark Results (N={N}):\n"
            f"Insertion time: {insert_time:.4f} seconds\n"
            f"Search time (for {len(search_names)} queries, found {found_count}): {search_time:.4f} seconds\n"
            f"Deletion time (for 100 deletions): {delete_time:.4f} seconds\n"
        )

        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, result_text)

        self.draw_tree()

def run_benchmark_for_sizes(sizes, num_search=100, num_delete=50):
    bst_times = {'insert': [], 'search': [], 'delete': []}
    avl_times = {'insert': [], 'search': [], 'delete': []}
    rbt_times = {'insert': [], 'search': [], 'delete': []}

    for n in sizes:
        names  = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
        search_names = random.sample(names, min(num_search, n))
        delete_names = random.sample(names, min(num_delete, n))

        bst = BST()
        start = time.time()
        for i in range(n):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            bst.search(bst.root, name)
        bst_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_times['delete'].append(time.time() - start)

        avl = AVLTree()
        start = time.time()
        for i in range(n):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            avl.search(avl.root, name)
        avl_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_times['delete'].append(time.time() - start)

        rbt = RedBlackTree()
        start = time.time()
        for i in range(n):
            rbt.insert(names[i], phones[i])
        rbt_times['insert'].append(time.time() - start)

        start = time.time()
        for name in search_names:
            rbt.search(rbt.root, name)
        rbt_times['search'].append(time.time() - start)

        start = time.time()
        for name in delete_names:
            rbt.delete(name)
        rbt_times['delete'].append(time.time() - start)

    plt.figure(figsize=(12, 8))

    plt.subplot(3, 1, 1)
    plt.plot(sizes, bst_times['insert'], label='BST Insert')
    plt.plot(sizes, avl_times['insert'], label='AVL Insert')
    plt.plot(sizes, rbt_times['insert'], label='RBT Insert')
    plt.ylabel('Time (seconds)')
    plt.title('Insertion Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 2)
    plt.plot(sizes, bst_times['search'], label='BST Search')
    plt.plot(sizes, avl_times['search'], label='AVL Search')
    plt.plot(sizes, rbt_times['search'], label='RBT Search')
    plt.ylabel('Time (seconds)')
    plt.title('Search Time vs Input Size')
    plt.legend()

    plt.subplot(3, 1, 3)
    plt.plot(sizes, bst_times['delete'], label='BST Delete')
    plt.plot(sizes, avl_times['delete'], label='AVL Delete')
    plt.plot(sizes, rbt_times['delete'], label='RBT Delete')
    plt.xlabel('Number of Nodes')
    plt.ylabel('Time (seconds)')
    plt.title('Deletion Time vs Input Size')
    plt.legend()

    plt.tight_layout()
    plt.show()

class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs RBT Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 1000 entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack(pady=10)

        self.tree = ttk.Treeview(master, columns=("BST", "AVL", "RBT"), show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RBT Time (s)")
        self.tree.pack(pady=10)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)

        N = 1000
        names  = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(N)]
        phones = [''.join(random.choices(string.digits, k=10)) for _ in range(N)]
        search_names = random.sample(names, N // 2) + ['notfoundname'] * (N // 2)
        delete_names = random.sample(names, 100)

        bst = BST()
        start = time.time()
        for i in range(N):
            bst.root = bst.insert(bst.root, names[i], phones[i])
        bst_insert = time.time() - start

        start = time.time()
        found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
        bst_search = time.time() - start

        start = time.time()
        for name in delete_names:
            bst.root = bst.delete(bst.root, name)
        bst_delete = time.time() - start

        avl = AVLTree()
        start = time.time()
        for i in range(N):
            avl.root = avl.insert(avl.root, names[i], phones[i])
        avl_insert = time.time() - start

        start = time.time()
        found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
        avl_search = time.time() - start

        start = time.time()
        for name in delete_names:
            avl.root = avl.delete(avl.root, name)
        avl_delete = time.time() - start

        rbt = RedBlackTree()
        start = time.time()
        for i in range(N):
            rbt.insert(names[i], phones[i])
        rbt_insert = time.time() - start

        start = time.time()
        found_rbt = sum(1 for name in search_names if not rbt._is_nil(rbt.search(rbt.root, name)))
        rbt_search = time.time() - start

        start = time.time()
        for name in delete_names:
            rbt.delete(name)
        rbt_delete = time.time() - start

        summary = (
            f"Insertion Time: BST: {bst_insert:.6f}s, AVL: {avl_insert:.6f}s, RBT: {rbt_insert:.6f}s\n"
            f"Search Time:    BST: {bst_search:.6f}s, AVL: {avl_search:.6f}s, RBT: {rbt_search:.6f}s\n"
            f"Deletion Time:  BST: {bst_delete:.6f}s, AVL: {avl_delete:.6f}s, RBT: {rbt_delete:.6f}s\n"
            f"Found in Search: BST: {found_bst}, AVL: {found_avl}, RBT: {found_rbt} out of {len(search_names)}\n"
        )
        self.result_text.insert(tk.END, summary)

        for row in self.tree.get_children():
            self.tree.delete(row)

        for op, b, a, r in [
            ('Insertions', bst_insert, avl_insert, rbt_insert),
            ('Searches',   bst_search, avl_search, rbt_search),
            ('Deletions',  bst_delete, avl_delete, rbt_delete),
        ]:
            self.tree.insert('', tk.END, values=(f"{b:.6f}", f"{a:.6f}", f"{r:.6f}"), text=op)

        sizes_to_test = [100, 200, 400, 800, 1600, 3200, 5000, 7500, 10000]
        run_benchmark_for_sizes(sizes_to_test)

if __name__ == "__main__":
    root = tk.Tk()
    app = RBTreeApp(root)

    bench_win = tk.Toplevel(root)
    bench_app = BenchmarkApp(bench_win)

    root.mainloop()