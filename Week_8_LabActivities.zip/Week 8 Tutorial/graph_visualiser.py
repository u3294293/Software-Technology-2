from graph import Graph
import tkinter as tk
import tkinter.simpledialog as simpledialog
import tkinter.messagebox as messagebox
import math
import time
import threading


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("500x620")
        self.graph = graph

        self.canvas = tk.Canvas(self, width=480, height=400, bg="white")
        self.canvas.pack(pady=5)

        self.vertex_positions = {}
        self.vertex_circles = {}
        self.node_radius = 20
        self.spacing = 150
        self.center = (240, 200)

        row1 = tk.Frame(self)
        row1.pack(pady=3)

        tk.Button(row1, text="Add Vertex",
                  command=self.add_vertex).pack(side=tk.LEFT, padx=4)
        tk.Button(row1, text="Remove Vertex",
                  command=self.remove_vertex).pack(side=tk.LEFT, padx=4)
        tk.Button(row1, text="Add Edge",
                  command=self.add_edge).pack(side=tk.LEFT, padx=4)
        tk.Button(row1, text="Remove Edge",
                  command=self.remove_edge).pack(side=tk.LEFT, padx=4)

        row2 = tk.Frame(self)
        row2.pack(pady=3)

        tk.Button(row2, text="Run BFS",
                  command=lambda: self.run_traversal("bfs")).pack(side=tk.LEFT, padx=4)
        tk.Button(row2, text="Run DFS",
                  command=lambda: self.run_traversal("dfs")).pack(side=tk.LEFT, padx=4)
        tk.Button(row2, text="Reset Colors",
                  command=self.reset_colors).pack(side=tk.LEFT, padx=4)

        self.info_label = tk.Label(self, text="", font=("Arial", 10))
        self.info_label.pack(pady=4)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_circles.clear()

        vertices = list(self.graph.graph.keys())
        n = len(vertices)
        if n == 0:
            return

        angle_gap = 360 / n
        cx, cy = self.center

        for i, v in enumerate(vertices):
            angle = i * angle_gap
            x = cx + self.spacing * math.cos(math.radians(angle))
            y = cy + self.spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)
            oid = self.canvas.create_oval(
                x - self.node_radius, y - self.node_radius,
                x + self.node_radius, y + self.node_radius,
                fill="lightblue", outline="black", width=2
            )
            self.vertex_circles[v] = oid
            self.canvas.create_text(x, y, text=v, font=("Arial", 11, "bold"))

        drawn = set()
        for v in vertices:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                if not self.graph.directed and (nbr, v) in drawn:
                    continue
                drawn.add((v, nbr))

                x2, y2 = self.vertex_positions[nbr]
                dx, dy = x2 - x1, y2 - y1
                dist = math.sqrt(dx * dx + dy * dy)
                if dist == 0:
                    continue
                ox = dx / dist * self.node_radius
                oy = dy / dist * self.node_radius

                self.canvas.create_line(
                    x1 + ox, y1 + oy, x2 - ox, y2 - oy,
                    arrow=tk.LAST if self.graph.directed else None,
                    width=2
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mx, my, text=str(w),
                                            fill="red", font=("Arial", 9, "italic"))

    def reset_colors(self):
        for oid in self.vertex_circles.values():
            self.canvas.itemconfig(oid, fill="lightblue")
        self.info_label.config(text="")

    def highlight_vertex(self, vertex, color):
        oid = self.vertex_circles.get(vertex)
        if oid:
            self.canvas.itemconfig(oid, fill=color)
            self.update()


    def add_vertex(self):
        name = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if name:
            name = name.strip().upper()
            if name in self.graph.graph:
                messagebox.showinfo("Info", f"Vertex '{name}' already exists.")
            else:
                self.graph.add_vertex(name)
                self.info_label.config(text=f"Added vertex '{name}'")
                self.draw_graph()

    def remove_vertex(self):
        name = simpledialog.askstring("Remove Vertex", "Enter vertex name to remove:")
        if name:
            name = name.strip().upper()
            if name not in self.graph.graph:
                messagebox.showinfo("Info", f"Vertex '{name}' not found.")
            else:
                self.graph.remove_vertex(name)
                self.info_label.config(text=f"Removed vertex '{name}'")
                self.draw_graph()

    def add_edge(self):
        v1 = simpledialog.askstring("Add Edge", "Enter first vertex:")
        if not v1:
            return
        v2 = simpledialog.askstring("Add Edge", "Enter second vertex:")
        if not v2:
            return
        v1, v2 = v1.strip().upper(), v2.strip().upper()

        weight = 0
        if self.graph.weighted:
            w_str = simpledialog.askstring("Add Edge", "Enter weight:")
            try:
                weight = int(w_str)
            except (TypeError, ValueError):
                messagebox.showinfo("Info", "Invalid weight — defaulting to 0.")

        if v1 not in self.graph.graph or v2 not in self.graph.graph:
            messagebox.showinfo("Info", "One or both vertices not found.")
        else:
            self.graph.add_edge(v1, v2, weight)
            self.info_label.config(text=f"Added edge {v1} → {v2}" + (f" (w={weight})" if self.graph.weighted else ""))
            self.draw_graph()

    def remove_edge(self):
        v1 = simpledialog.askstring("Remove Edge", "Enter first vertex:")
        if not v1:
            return
        v2 = simpledialog.askstring("Remove Edge", "Enter second vertex:")
        if not v2:
            return
        v1, v2 = v1.strip().upper(), v2.strip().upper()
        self.graph.remove_edge(v1, v2)
        self.info_label.config(text=f"Removed edge {v1} → {v2}")
        self.draw_graph()

    def run_traversal(self, method):
        def worker():
            self.reset_colors()
            start = "A" if "A" in self.graph.graph else next(iter(self.graph.graph), None)
            if not start:
                self.info_label.config(text="Graph is empty.")
                return

            visited = set()

            if method == "bfs":
                queue = [start]
                self.info_label.config(text="Running BFS…")
                while queue:
                    v = queue.pop(0)
                    if v not in visited:
                        visited.add(v)
                        self.highlight_vertex(v, "orange")
                        self.info_label.config(text=f"BFS visiting: {v}")
                        time.sleep(0.7)
                        for nbr in self.graph.graph[v]:
                            if nbr not in visited:
                                queue.append(nbr)
                self.info_label.config(text=f"BFS complete. Order: {' → '.join(visited)}")

            elif method == "dfs":
                stack = [start]
                order = []
                self.info_label.config(text="Running DFS…")
                while stack:
                    v = stack.pop()
                    if v not in visited:
                        visited.add(v)
                        order.append(v)
                        self.highlight_vertex(v, "mediumpurple")
                        self.info_label.config(text=f"DFS visiting: {v}")
                        time.sleep(0.7)
                        for nbr in reversed(self.graph.graph[v]):
                            if nbr not in visited:
                                stack.append(nbr)
                self.info_label.config(text=f"DFS complete. Order: {' → '.join(order)}")

        threading.Thread(target=worker, daemon=True).start()


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    for v in ["A", "B", "C"]:
        g.add_vertex(v)
    g.add_edge("A", "B", 10)
    g.add_edge("B", "C", 20)
    g.add_edge("C", "A", 30)

    app = GraphVisualizer(g)
    app.mainloop()