import random
import timeit
import sys
sys.set_int_max_str_digits(10000)

# RECURSION
# At its core, recursion involves solving a problem
# by breaking it down into smaller, more manageable instances of the same problem.

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case


def sum_of_natural_numbers_iteration(n):
    n_sum = 0
    for i in range(1, n + 1):
        n_sum += i
    return n_sum


# Example usage:
#result1 = sum_of_natural_numbers_iteration(5)  # Calculates 1 + 2 + 3 + 4 + 5
#print(f"The sum (iteration) of the first 5 natural numbers is {result1}")
# Example usage:
#result2 = sum_of_natural_numbers(5)  # Calculates 1 + 2 + 3 + 4 + 5
#print(f"The sum of the first 5 natural numbers is {result2}")


# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

def fibonacci_iteration(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        value1, value2 = 0, 1
        for i in range(2, n + 1):
            value3 = value1 + value2
            value1 = value2
            value2 = value3
        return value2


#result2 = fibonacci_iteration(2000)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
#print(f"The 7th Fibonacci number (iteration) is {result2}")
#result = fibonacci(2000)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
#print(f"The 7th Fibonacci number is {result}")


def factorial(n):
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

def factorial_iterative(n):
    value = 1
    for i in range(1, n + 1):
        value *= i
    return value



num = 2000

#result2 = factorial_iterative(num)
#print(f"The factorial of {num} is {result2}")


#result = factorial(num)
#print(f"The factorial of {num} is {result}")


# Task 3

# moves = 0
#
# def main():
#     global moves
#     n = eval(input("Enter number of disks: "))
#
#     moves = 0
#
#     print("The moves are:")
#     moveDisks(n, 'A', 'B', 'C')
#     print("Number of moves is", moves)
#
#
# def moveDisks(n, fromTower, toTower, auxTower):
#     global moves
#     if n == 1:
#        # print("Move disk", n, "from", fromTower, "to", toTower)
#         moves += 1
#     else:
#         moveDisks(n - 1, fromTower, auxTower, toTower)
#        # print("Move disk", n, "from", fromTower, "to", toTower)
#         moves += 1
#         moveDisks(n - 1, auxTower, toTower, fromTower)
#
#
# main()


# Task 4
#
# from tkinter import *  # Import tkinter
#
#
# class SierpinskiTriangle:
#     def __init__(self):
#         window = Tk()  # Create a window
#         window.title("Sierpinski Triangle")  # Set a title
#         self.width = 200
#         self.height = 200
#         self.canvas = Canvas(window, width=self.width, height=self.height)
#         self.canvas.pack()
#
#         # Add a label, an entry, and a button to frame1
#         frame1 = Frame(window)  # Create and add a frame to window
#         frame1.pack()
#         Label(frame1, text="Enter an order: ").pack(side=LEFT)
#         self.order = StringVar()
#         entry = Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
#         Button(frame1, text="Display Sierpinski Triangle", command=self.display).pack(side=LEFT)
#
#         window.mainloop()  # Create an event loop
#
#     def display(self):
#         self.canvas.delete("line")
#         p1 = [self.width / 2, 10]
#         p2 = [10, self.height - 10]
#         p3 = [self.width - 10, self.height - 10]
#         self.displayTriangles(int(self.order.get()), p1, p2, p3)
#
#     def displayTriangles(self, order, p1, p2, p3):
#         if order == 0:  # Base condition
#             # Draw a triangle to connect three points
#             self.drawLine(p1, p2)
#             self.drawLine(p2, p3)
#             self.drawLine(p3, p1)
#         else:
#             # Get the midpoint of each triangle's edge
#             p12 = self.midpoint(p1, p2)
#             p23 = self.midpoint(p2, p3)
#             p31 = self.midpoint(p3, p1)
#
#             # Recursively display three triangles
#             self.displayTriangles(order - 1, p1, p12, p31)
#             self.displayTriangles(order - 1, p12, p2, p23)
#             self.displayTriangles(order - 1, p31, p23, p3)
#
#     def drawLine(self, p1, p2):
#         self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
#
#     # Return the midpoint between two points
#     def midpoint(self, p1, p2):
#         p = 2 * [0]
#         p[0] = (p1[0] + p2[0]) / 2
#         p[1] = (p1[1] + p2[1]) / 2
#         return p
#
#
# # Instantiate the class
# SierpinskiTriangle()


# snowflake

import math
from tkinter import *


class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 600
        self.height = 600
        self.canvas = Canvas(window, width=self.width, height=self.height, bg="white")
        self.canvas.pack()

        frame = Frame(window)
        frame.pack()

        Label(frame, text="Enter an order: ").pack(side=LEFT)
        self.order_var = StringVar()
        Entry(frame, textvariable=self.order_var, width=5).pack(side=LEFT)
        Button(frame, text="Display Koch Snowflake", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        try:
            order = int(self.order_var.get())
        except ValueError:
            return

        margin = 100
        p1 = [self.width / 2, margin]  # Top
        p2 = [margin, self.height - margin - 50]  # Bottom Left
        p3 = [self.width - margin, self.height - margin - 50]  # Bottom Right

        self.drawKochLine(order, p1, p3)
        self.drawKochLine(order, p3, p2)
        self.drawKochLine(order, p2, p1)

    def drawKochLine(self, order, p1, p5):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p5[0], p5[1], tags="line")
        else:
            dx = p5[0] - p1[0]
            dy = p5[1] - p1[1]


            p2 = [p1[0] + dx / 3, p1[1] + dy / 3]
            p4 = [p1[0] + 2 * dx / 3, p1[1] + 2 * dy / 3]

            angle = -math.pi / 3

            vx = p4[0] - p2[0]
            vy = p4[1] - p2[1]

            p3 = [
                p2[0] + vx * math.cos(angle) - vy * math.sin(angle),
                p2[1] + vx * math.sin(angle) + vy * math.cos(angle)
            ]

            self.drawKochLine(order - 1, p1, p2)
            self.drawKochLine(order - 1, p2, p3)
            self.drawKochLine(order - 1, p3, p4)
            self.drawKochLine(order - 1, p4, p5)


KochSnowflake()